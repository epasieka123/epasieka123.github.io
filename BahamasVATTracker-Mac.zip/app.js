/* ---------------------------------------------------------------
   Bahamas VAT Tracker — standalone browser app (no Electron)
   Data persists via File System Access API, one JSON file per
   company inside a folder you choose (e.g. your OneDrive folder).
   localStorage is kept only as an instant local safety cache.
--------------------------------------------------------------- */
const STORAGE_KEY = 'bahamasVatTracker';
const LEGACY_FILE = 'bahamas_vat_data.json';
const REGISTRY_FILE = 'vat_companies.json';
const FS_SUPPORTED = typeof window.showDirectoryPicker === 'function';

const PAGES = [
  {id:'summary', label:'VAT Return Summary'},
  {id:'revenue', label:'Sales Revenue'},
  {id:'utilities', label:'Utilities'},
  {id:'localSpending', label:'Local Spending'},
  {id:'supplies', label:'Supplies'},
  {id:'repairs', label:'Repairs'},
  {id:'duties', label:'Duties'},
  {id:'travel', label:'Travel'},
  {id:'settings', label:'Settings'},
];

function blankQuarter(){
  return {
    vatRate: 0.10,
    exchangeRate: 1.4,
    defaultCurrency: 'USD',
    paypalFeeRate: 0.03,
    utilities: [],
    localSpending: [],
    supplies: [],
    repairs: [],
    travel: [],
    duties: [],
    revenue: {totalPayouts:0, cleaning:0, management:0, platformFee:0}
  };
}

function currentQuarterLabel(){
  const d = new Date();
  const q = Math.floor(d.getMonth()/3)+1;
  return `${d.getFullYear()}-Q${q}`;
}

function seedQ2_2026(){
  const q = blankQuarter();
  q.utilities = [
    {date:'', desc:'H1 BPL 03', amount:219.63, vat:'Y'},
    {date:'', desc:'H2 BPL 03', amount:123.14, vat:'Y'},
    {date:'', desc:'H3 BPL 03', amount:99.96, vat:'Y'},
    {date:'2026-04-09', desc:'Propane Refill 100 H3 (Jonathan)', amount:115.00, vat:'Y'},
    {date:'', desc:'Water H1-H2', amount:85.80, vat:'Y'},
    {date:'', desc:'Water H3', amount:36.00, vat:'Y'},
    {date:'', desc:'H1 BPL 04', amount:221.45, vat:'Y'},
    {date:'', desc:'H2 BPL 04', amount:163.35, vat:'Y'},
    {date:'', desc:'H3 BPL 04', amount:203.56, vat:'Y'},
    {date:'', desc:'H1 BPL 05', amount:178.03, vat:'Y'},
    {date:'', desc:'H2 BPL 05', amount:200.63, vat:'Y'},
    {date:'', desc:'H3 BPL 05', amount:188.30, vat:'Y'},
  ];
  q.localSpending = [
    {date:'', desc:'Navado Concrete Driveway', amount:50.00, vat:'N'},
    {date:'', desc:'Karlos - new copper in AC H3', amount:150.00, vat:'N'},
    {date:'', desc:'Insurance', amount:3924.30, vat:'N'},
    {date:'', desc:'Karlos - Hot Water Tank', amount:150.00, vat:'N'},
    {date:'', desc:'Karlos - XChurch AC 30k failure', amount:550.00, vat:'N'},
  ];
  q.supplies = [
    {date:'2024-04-16', vendor:'Amazon', desc:'Misc Supplies', amount:193.57, currency:'CDN'},
    {date:'', vendor:'Amazon', desc:'Amazon Seeds', amount:24.00, currency:'CDN'},
    {date:'', vendor:'Costco CA', desc:'Towels and kitchen ladder', amount:114.94, currency:'CDN'},
    {date:'', vendor:'Amazon', desc:'LED Bulbs', amount:43.04, currency:'CDN'},
    {date:'', vendor:'Amazon', desc:'New Frother', amount:60.90, currency:'CDN'},
    {date:'', vendor:'Amazon', desc:'Dyson Battery', amount:58.84, currency:'USD'},
    {date:'', vendor:'Eufy', desc:'Eufy Floor Cleaner', amount:38.84, currency:'USD'},
    {date:'', vendor:'Amazon', desc:'ATS Switch Moes', amount:129.14, currency:'CDN'},
    {date:'', vendor:'Amazon', desc:'Shop Vac Filters', amount:19.94, currency:'CDN'},
    {date:'', vendor:'Amazon', desc:'Back Up Battery Cords, Inlets and Panel', amount:162.31, currency:'CDN'},
    {date:'', vendor:'Amazon', desc:'Small funnels for oiling fans and AC units', amount:13.64, currency:'CDN'},
    {date:'', vendor:'Alibaba', desc:'Battery backup', amount:2946.30, currency:'USD'},
  ];
  q.repairs = [
    {date:'', vendor:'', desc:'AC Boards from China', amount:386.22, currency:'USD'},
    {date:'', vendor:'', desc:'Door Spindles', amount:53.35, currency:'CDN'},
    {date:'', vendor:'', desc:'Bearing for car', amount:186.49, currency:'CDN'},
    {date:'', vendor:'', desc:'New Ladder', amount:523.21, currency:'USD'},
    {date:'', vendor:'', desc:'4M Screws', amount:16.59, currency:'CDN'},
    {date:'', vendor:'', desc:'Hot water Tankless', amount:278.18, currency:'USD'},
    {date:'', vendor:'', desc:'Snorkel Sets', amount:134.76, currency:'USD'},
    {date:'', vendor:'', desc:'Trimmer Battery', amount:31.08, currency:'CDN'},
    {date:'', vendor:'', desc:'Bathroom Fan Motor', amount:23.09, currency:'CDN'},
  ];
  q.duties = [
    {date:'', ref:'EC 4581', itemValue:127.93, dutyPaid:30.16, currency:'USD'},
    {date:'', ref:'EC 4588', itemValue:75.63, dutyPaid:18.56, currency:'USD'},
  ];
  q.revenue = {totalPayouts:47979.29, cleaning:4705.00, management:4980.09, platformFee:2732.65};
  return q;
}

/* ---------------- Storage layer (File System Access API) ---------------- */
let ROOT_DIR = null;
let REGISTRY = null;
let ACTIVE_COMPANY = null;

function idbOpen(){
  return new Promise((resolve,reject)=>{
    const req = indexedDB.open('vatTrackerDB', 1);
    req.onupgradeneeded = ()=> req.result.createObjectStore('handles');
    req.onsuccess = ()=> resolve(req.result);
    req.onerror = ()=> reject(req.error);
  });
}
async function idbGet(key){
  const db = await idbOpen();
  return new Promise((resolve,reject)=>{
    const tx = db.transaction('handles','readonly');
    const req = tx.objectStore('handles').get(key);
    req.onsuccess = ()=> resolve(req.result || null);
    req.onerror = ()=> reject(req.error);
  });
}
async function idbSet(key, val){
  const db = await idbOpen();
  return new Promise((resolve,reject)=>{
    const tx = db.transaction('handles','readwrite');
    tx.objectStore('handles').put(val, key);
    tx.oncomplete = ()=> resolve();
    tx.onerror = ()=> reject(tx.error);
  });
}

async function ensurePermission(handle){
  const opts = {mode:'readwrite'};
  if((await handle.queryPermission(opts))==='granted') return true;
  if((await handle.requestPermission(opts))==='granted') return true;
  return false;
}

async function getRootDir(forcePrompt){
  if(ROOT_DIR && !forcePrompt && await ensurePermission(ROOT_DIR)) return ROOT_DIR;
  let handle = forcePrompt ? null : await idbGet('rootDir');
  if(handle && await ensurePermission(handle)){
    ROOT_DIR = handle;
    return handle;
  }
  handle = await window.showDirectoryPicker({mode:'readwrite'});
  await idbSet('rootDir', handle);
  ROOT_DIR = handle;
  return handle;
}

async function readJSONFile(dir, filename){
  try{
    const fh = await dir.getFileHandle(filename);
    const file = await fh.getFile();
    return JSON.parse(await file.text());
  }catch(e){ return null; }
}
async function writeJSONFile(dir, filename, obj){
  const fh = await dir.getFileHandle(filename, {create:true});
  const writable = await fh.createWritable();
  await writable.write(JSON.stringify(obj, null, 2));
  await writable.close();
}
async function fileExists(dir, filename){
  try{ await dir.getFileHandle(filename); return true; }catch(e){ return false; }
}
function slugify(name){
  return (name||'').toLowerCase().replace(/[^a-z0-9]+/g,'_').replace(/^_+|_+$/g,'') || 'company';
}
function makeCompanyId(){
  return 'co_' + Date.now().toString(36) + Math.random().toString(36).slice(2,6);
}

async function folderNeedsSetup(dir){
  const hasRegistry = await fileExists(dir, REGISTRY_FILE);
  const hasLegacy = await fileExists(dir, LEGACY_FILE);
  return !hasRegistry && !hasLegacy;
}

async function createFirstCompany(dir, name){
  const id = makeCompanyId();
  const file = `vat_data_${slugify(name)}.json`;
  const blank = { currentQuarter: currentQuarterLabel(), quarters: { [currentQuarterLabel()]: blankQuarter() } };
  await writeJSONFile(dir, file, blank);
  const reg = { companies: [{id, name, file}], activeCompanyId: id };
  await writeJSONFile(dir, REGISTRY_FILE, reg);
  return reg;
}

async function loadRegistry(dir){
  let reg = await readJSONFile(dir, REGISTRY_FILE);
  if(reg && Array.isArray(reg.companies) && reg.companies.length) return reg;

  if(await fileExists(dir, LEGACY_FILE)){
    reg = {
      companies: [{id: makeCompanyId(), name: '1189487 Alberta Ltd', file: LEGACY_FILE}],
      activeCompanyId: null
    };
    reg.activeCompanyId = reg.companies[0].id;
    await writeJSONFile(dir, REGISTRY_FILE, reg);
    return reg;
  }

  const id = makeCompanyId();
  const file = `vat_data_${slugify('Company 1')}.json`;
  const blank = { currentQuarter: currentQuarterLabel(), quarters: { [currentQuarterLabel()]: blankQuarter() } };
  await writeJSONFile(dir, file, blank);
  reg = { companies: [{id, name:'Company 1', file}], activeCompanyId: id };
  await writeJSONFile(dir, REGISTRY_FILE, reg);
  return reg;
}

async function loadCompanyData(dir, company){
  const data = await readJSONFile(dir, company.file);
  if(data) return data;
  const blank = { currentQuarter: currentQuarterLabel(), quarters: { [currentQuarterLabel()]: blankQuarter() } };
  await writeJSONFile(dir, company.file, blank);
  return blank;
}

async function initStorage(){
  if(!FS_SUPPORTED){
    ACTIVE_COMPANY = {id:'local', name:'Local (browser storage)', file:null};
    const raw = localStorage.getItem(STORAGE_KEY);
    if(raw){ try{ return JSON.parse(raw); }catch(e){} }
    return { currentQuarter: currentQuarterLabel(), quarters: { [currentQuarterLabel()]: seedQ2_2026() } };
  }
  const dir = await getRootDir(false);
  if(await folderNeedsSetup(dir)){
    const name = await promptForCompanyName();
    REGISTRY = await createFirstCompany(dir, name);
  } else {
    REGISTRY = await loadRegistry(dir);
  }
  ACTIVE_COMPANY = REGISTRY.companies.find(c=>c.id===REGISTRY.activeCompanyId) || REGISTRY.companies[0];
  return await loadCompanyData(dir, ACTIVE_COMPANY);
}

async function switchCompany(companyId){
  if(!ACTIVE_COMPANY || companyId===ACTIVE_COMPANY.id) return;
  await forceSave();
  const dir = await getRootDir(false);
  const target = REGISTRY.companies.find(c=>c.id===companyId);
  if(!target) return;
  ACTIVE_COMPANY = target;
  REGISTRY.activeCompanyId = companyId;
  await writeJSONFile(dir, REGISTRY_FILE, REGISTRY);
  DATA = await loadCompanyData(dir, ACTIVE_COMPANY);
  currentPage = 'summary';
  renderSidebar();
  renderPage();
  setSaveStatus('saved');
  toast(`Switched to ${ACTIVE_COMPANY.name}`);
}

async function renameActiveCompany(newName){
  newName = (newName||'').trim();
  if(!newName || !ACTIVE_COMPANY || !REGISTRY) return;
  if(newName === ACTIVE_COMPANY.name) return;
  const entry = REGISTRY.companies.find(c=>c.id===ACTIVE_COMPANY.id);
  if(!entry) return;
  entry.name = newName;
  ACTIVE_COMPANY.name = newName;
  const dir = await getRootDir(false);
  await writeJSONFile(dir, REGISTRY_FILE, REGISTRY);
  renderSidebar();
  setSaveStatus('saved');
}

async function addCompany(name){
  const dir = await getRootDir(false);
  const id = makeCompanyId();
  const base = slugify(name);
  let file = `vat_data_${base}.json`, n = 2;
  while(await fileExists(dir, file)){ file = `vat_data_${base}_${n++}.json`; }
  const blank = { currentQuarter: currentQuarterLabel(), quarters: { [currentQuarterLabel()]: blankQuarter() } };
  await writeJSONFile(dir, file, blank);
  REGISTRY.companies.push({id, name, file});
  await writeJSONFile(dir, REGISTRY_FILE, REGISTRY);
  await switchCompany(id);
}

let DATA = null;
let currentPage = 'summary';
let saveTimer = null;

function save(){
  if(ACTIVE_COMPANY && ACTIVE_COMPANY.file) localStorage.setItem(STORAGE_KEY+'_'+ACTIVE_COMPANY.id, JSON.stringify(DATA));
  setSaveStatus('saving');
  clearTimeout(saveTimer);
  saveTimer = setTimeout(async ()=>{
    if(FS_SUPPORTED && ROOT_DIR && ACTIVE_COMPANY && ACTIVE_COMPANY.file){
      try{
        await writeJSONFile(ROOT_DIR, ACTIVE_COMPANY.file, DATA);
        setSaveStatus('saved');
      }catch(e){ console.error(e); setSaveStatus('error'); }
    } else {
      setSaveStatus('saved');
    }
  }, 250);
}

async function forceSave(){
  clearTimeout(saveTimer);
  if(ACTIVE_COMPANY && ACTIVE_COMPANY.file) localStorage.setItem(STORAGE_KEY+'_'+ACTIVE_COMPANY.id, JSON.stringify(DATA));
  setSaveStatus('saving');
  if(FS_SUPPORTED && ROOT_DIR && ACTIVE_COMPANY && ACTIVE_COMPANY.file){
    try{
      await writeJSONFile(ROOT_DIR, ACTIVE_COMPANY.file, DATA);
      setSaveStatus('saved');
      toast('Saved');
    }catch(e){ console.error(e); setSaveStatus('error'); }
  } else {
    setSaveStatus('saved');
    toast('Saved');
  }
}

document.addEventListener('keydown', (e)=>{
  if((e.ctrlKey || e.metaKey) && e.key.toLowerCase()==='s'){
    e.preventDefault();
    forceSave();
  }
});

function setSaveStatus(state){
  const el = document.getElementById('saveStatus');
  if(!el) return;
  if(state==='saving'){ el.textContent='Saving…'; el.style.color='#8a6a1f'; el.style.borderColor='#e8d9b0'; el.style.background='#fffaf0'; }
  else if(state==='saved'){ el.textContent='All changes saved'; el.style.color='#0b6e4f'; el.style.borderColor='#cdeee0'; el.style.background='#f2fbf7'; }
  else { el.textContent='Save failed — check disk/permissions'; el.style.color='#b3261e'; el.style.borderColor='#f3c9c4'; el.style.background='#fdf3f2'; }
}

function q(){ return DATA.quarters[DATA.currentQuarter]; }

function toast(msg){
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(toast._t);
  toast._t = setTimeout(()=>t.classList.remove('show'), 1800);
}

function usd(amount, currency, er){
  amount = parseFloat(amount)||0;
  if((currency||'USD').toUpperCase()==='CDN') return amount/(parseFloat(er)||1);
  return amount;
}
function getTravelTotalUSD(){
  const s = q();
  return s.travel.reduce((a,r)=>a+usd(r.amount,r.currency,s.exchangeRate),0);
}
function vatOf(amount, flag, rate){
  amount = parseFloat(amount)||0;
  return (String(flag).toUpperCase()==='Y') ? amount*rate : 0;
}
function fmt(n){
  n = n||0;
  const neg = n<0;
  const s = Math.abs(n).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2});
  return (neg?'($':'$') + s + (neg?')':'');
}

/* ---------------- Sidebar / Nav ---------------- */
function renderSidebar(){
  const companySel = document.getElementById('companySelect');
  if(companySel){
    companySel.innerHTML = '';
    const list = FS_SUPPORTED && REGISTRY ? REGISTRY.companies : [ACTIVE_COMPANY];
    list.forEach(c=>{
      const o = document.createElement('option');
      o.value = c.id; o.textContent = c.name;
      if(ACTIVE_COMPANY && c.id===ACTIVE_COMPANY.id) o.selected = true;
      companySel.appendChild(o);
    });
    companySel.disabled = !FS_SUPPORTED;
    companySel.onchange = ()=>{ switchCompany(companySel.value); };
  }
  const addCompanyBtn = document.getElementById('addCompanyBtn');
  if(addCompanyBtn){
    addCompanyBtn.style.display = FS_SUPPORTED ? '' : 'none';
    addCompanyBtn.onclick = ()=> openNewCompanyModal();
  }

  const sel = document.getElementById('quarterSelect');
  sel.innerHTML = '';
  Object.keys(DATA.quarters).sort().forEach(k=>{
    const o = document.createElement('option');
    o.value = k; o.textContent = k;
    if(k===DATA.currentQuarter) o.selected = true;
    sel.appendChild(o);
  });
  sel.onchange = ()=>{ DATA.currentQuarter = sel.value; save(); renderPage(); };

  document.getElementById('newQuarterBtn').onclick = ()=>{
    openNewQuarterModal();
  };

  const nav = document.getElementById('nav');
  nav.innerHTML = '';
  PAGES.forEach(p=>{
    const b = document.createElement('button');
    b.className = 'navbtn' + (p.id===currentPage ? ' active':'');
    b.textContent = p.label;
    b.onclick = ()=>{ currentPage = p.id; renderSidebar(); renderPage(); };
    nav.appendChild(b);
  });
}

function nextQuarterGuess(){
  const m = DATA.currentQuarter.match(/(\d{4})-Q(\d)/);
  if(!m) return currentQuarterLabel();
  let [_, y, n] = m; y=+y; n=+n;
  n++; if(n>4){n=1;y++;}
  return `${y}-Q${n}`;
}

function openNewQuarterModal(){
  const overlay = document.createElement('div');
  overlay.id = 'modalOverlay';
  overlay.innerHTML = `
    <div class="modalBox">
      <h3>New Quarter</h3>
      <div class="field">
        <label>Quarter label</label>
        <input type="text" id="newQuarterInput" value="${nextQuarterGuess()}">
        <div class="hint">e.g. 2026-Q3. VAT rate and exchange rate carry over from ${DATA.currentQuarter}.</div>
      </div>
      <div class="modalActions">
        <button class="toolbtn" id="cancelQuarterBtn">Cancel</button>
        <button class="addrow" id="createQuarterBtn">Create Quarter</button>
      </div>
    </div>
  `;
  document.body.appendChild(overlay);
  const input = document.getElementById('newQuarterInput');
  input.focus();
  input.select();

  const close = ()=> overlay.remove();
  document.getElementById('cancelQuarterBtn').onclick = close;
  overlay.addEventListener('click', (e)=>{ if(e.target===overlay) close(); });

  const create = ()=>{
    const label = input.value.trim();
    if(!label) return;
    if(DATA.quarters[label]){ alert('That quarter already exists.'); return; }
    const prev = q();
    const nq = blankQuarter();
    nq.vatRate = prev.vatRate;
    nq.exchangeRate = prev.exchangeRate;
    nq.paypalFeeRate = prev.paypalFeeRate;
    nq.defaultCurrency = prev.defaultCurrency;
    DATA.quarters[label] = nq;
    DATA.currentQuarter = label;
    save(); renderSidebar(); renderPage();
    toast(`Created ${label}`);
    close();
  };
  document.getElementById('createQuarterBtn').onclick = create;
  input.addEventListener('keydown', (e)=>{ if(e.key==='Enter') create(); if(e.key==='Escape') close(); });
}

function openNewCompanyModal(){
  const overlay = document.createElement('div');
  overlay.id = 'modalOverlay';
  overlay.innerHTML = `
    <div class="modalBox">
      <h3>Add Company</h3>
      <div class="field">
        <label>Company name</label>
        <input type="text" id="newCompanyInput" placeholder="e.g. 1189487 Alberta Ltd">
        <div class="hint">Creates a new, separate data file for this company. Your other companies are unaffected.</div>
      </div>
      <div class="modalActions">
        <button class="toolbtn" id="cancelCompanyBtn">Cancel</button>
        <button class="addrow" id="createCompanyBtn">Add Company</button>
      </div>
    </div>
  `;
  document.body.appendChild(overlay);
  const input = document.getElementById('newCompanyInput');
  input.focus();

  const close = ()=> overlay.remove();
  document.getElementById('cancelCompanyBtn').onclick = close;
  overlay.addEventListener('click', (e)=>{ if(e.target===overlay) close(); });

  const create = async ()=>{
    const name = input.value.trim();
    if(!name) return;
    if(REGISTRY.companies.some(c=>c.name.toLowerCase()===name.toLowerCase())){
      alert('A company with that name already exists.'); return;
    }
    await addCompany(name);
    close();
  };
  document.getElementById('createCompanyBtn').onclick = create;
  input.addEventListener('keydown', (e)=>{ if(e.key==='Enter') create(); if(e.key==='Escape') close(); });
}

/* ---------------- Generic table page builder ---------------- */
function renderSimpleVatTable(container, cfg){
  const data = q()[cfg.key];
  const rate = q().vatRate;
  let totalAmt=0, totalVat=0;
  const rows = data.map((row,i)=>{
    const vat = vatOf(row.amount, row.vat, rate);
    totalAmt += parseFloat(row.amount)||0;
    totalVat += vat;
    return `<tr>
      <td><input data-i="${i}" data-f="date" value="${row.date||''}" placeholder="date"></td>
      <td><input data-i="${i}" data-f="desc" value="${esc(row.desc||'')}" placeholder="Vendor / description"></td>
      <td><input class="num" type="number" step="0.01" data-i="${i}" data-f="amount" value="${row.amount||''}"></td>
      <td>
        <select data-i="${i}" data-f="vat">
          <option value="Y" ${row.vat==='Y'?'selected':''}>Y</option>
          <option value="N" ${row.vat==='N'?'selected':''}>N</option>
        </select>
      </td>
      <td class="num vatcell" data-row="${i}">${fmt(vat)}</td>
      <td><button class="delbtn" data-i="${i}" data-del="1">✕</button></td>
    </tr>`;
  }).join('');
  container.innerHTML = `
    <h2>${label(cfg.key)}</h2>
    <div class="pagesub">VAT calculated at ${(rate*100).toFixed(1)}% of amount when flagged Y. Amounts are USD.</div>
    <table>
      <thead><tr><th>Date</th><th>Vendor / Description</th><th style="text-align:right">Amount (USD)</th><th>VAT (Y/N)</th><th style="text-align:right">VAT Amount</th><th></th></tr></thead>
      <tbody>${rows || emptyRow(6)}</tbody>
      <tfoot><tr><td colspan="2">TOTAL</td><td class="num" id="ft-totalAmt">${fmt(totalAmt)}</td><td></td><td class="num" id="ft-totalVat">${fmt(totalVat)}</td><td></td></tr>
      <tr><td colspan="2">Before VAT</td><td class="num" id="ft-beforeVat">${fmt(totalAmt-totalVat)}</td><td colspan="3"></td></tr></tfoot>
    </table>
    <button class="addrow" data-add="1">+ Add line</button>
  `;
  wireSimpleTable(container, cfg.key, data);
}

function recalcSimpleTable(container, key){
  const data = q()[key];
  const rate = q().vatRate;
  let totalAmt=0, totalVat=0;
  data.forEach((row,i)=>{
    const vat = vatOf(row.amount, row.vat, rate);
    totalAmt += parseFloat(row.amount)||0;
    totalVat += vat;
    const cell = container.querySelector(`.vatcell[data-row="${i}"]`);
    if(cell) cell.textContent = fmt(vat);
  });
  const a = container.querySelector('#ft-totalAmt'); if(a) a.textContent = fmt(totalAmt);
  const v = container.querySelector('#ft-totalVat'); if(v) v.textContent = fmt(totalVat);
  const b = container.querySelector('#ft-beforeVat'); if(b) b.textContent = fmt(totalAmt-totalVat);
}

function wireSimpleTable(container, key, data){
  container.querySelectorAll('tbody input').forEach(el=>{
    el.addEventListener('input', ()=>{
      const i = +el.dataset.i, f = el.dataset.f;
      data[i][f] = el.value;
      save();
      if(f==='amount') recalcSimpleTable(container, key);
    });
  });
  container.querySelectorAll('tbody select').forEach(el=>{
    el.addEventListener('change', ()=>{
      const i = +el.dataset.i, f = el.dataset.f;
      data[i][f] = el.value;
      save();
      recalcSimpleTable(container, key);
    });
  });
  container.querySelectorAll('[data-del]').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      data.splice(+btn.dataset.i,1);
      save(); renderPage();
    });
  });
  const addBtn = container.querySelector('[data-add]');
  if(addBtn) addBtn.addEventListener('click', ()=>{
    data.push({date:'',desc:'',amount:'',vat:'Y'});
    save(); renderPage();
  });
}

function renderImportTable(container, cfg){
  const data = q()[cfg.key];
  const er = q().exchangeRate;
  let total=0;
  const rows = data.map((row,i)=>{
    const u = usd(row.amount, row.currency, er);
    total += u;
    return `<tr>
      <td><input data-i="${i}" data-f="date" value="${row.date||''}" placeholder="date"></td>
      <td><input data-i="${i}" data-f="vendor" value="${esc(row.vendor||'')}" placeholder="Vendor"></td>
      <td><input data-i="${i}" data-f="desc" value="${esc(row.desc||'')}" placeholder="Description"></td>
      <td><input class="num" type="number" step="0.01" data-i="${i}" data-f="amount" value="${row.amount||''}"></td>
      <td>
        <select data-i="${i}" data-f="currency">
          <option value="USD" ${(!row.currency||row.currency==='USD')?'selected':''}>USD</option>
          <option value="CDN" ${row.currency==='CDN'?'selected':''}>CDN</option>
        </select>
      </td>
      <td class="num usdcell" data-row="${i}">${fmt(u)}</td>
      <td><button class="delbtn" data-i="${i}" data-del="1">✕</button></td>
    </tr>`;
  }).join('');
  container.innerHTML = `
    <h2>${label(cfg.key)}</h2>
    <div class="pagesub">CDN amounts auto-convert to USD using the exchange rate set on the Settings page (currently ${er}).</div>
    <table>
      <thead><tr><th>Date</th><th>Vendor</th><th>Description</th><th style="text-align:right">Amount</th><th>Currency</th><th style="text-align:right">USD Amount</th><th></th></tr></thead>
      <tbody>${rows || emptyRow(7)}</tbody>
      <tfoot><tr><td colspan="5">TOTAL (USD)</td><td class="num" id="ft-total">${fmt(total)}</td><td></td></tr></tfoot>
    </table>
    <button class="addrow" data-add="1">+ Add line</button>
  `;
  wireImportTable(container, cfg.key, data);
}

function recalcImportTable(container, key){
  const data = q()[key];
  const er = q().exchangeRate;
  let total=0;
  data.forEach((row,i)=>{
    const u = usd(row.amount, row.currency, er);
    total += u;
    const cell = container.querySelector(`.usdcell[data-row="${i}"]`);
    if(cell) cell.textContent = fmt(u);
  });
  const t = container.querySelector('#ft-total'); if(t) t.textContent = fmt(total);
}

function wireImportTable(container, key, data){
  container.querySelectorAll('tbody input').forEach(el=>{
    el.addEventListener('input', ()=>{
      const i = +el.dataset.i, f = el.dataset.f;
      data[i][f] = el.value;
      save();
      if(f==='amount') recalcImportTable(container, key);
    });
  });
  container.querySelectorAll('tbody select').forEach(el=>{
    el.addEventListener('change', ()=>{
      const i = +el.dataset.i, f = el.dataset.f;
      data[i][f] = el.value;
      save();
      recalcImportTable(container, key);
    });
  });
  container.querySelectorAll('[data-del]').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      data.splice(+btn.dataset.i,1);
      save(); renderPage();
    });
  });
  const addBtn = container.querySelector('[data-add]');
  if(addBtn) addBtn.addEventListener('click', ()=>{
    data.push({date:'',vendor:'',desc:'',amount:'',currency: q().defaultCurrency || 'USD'});
    save(); renderPage();
  });
}

function renderDuties(container){
  const data = q().duties;
  let totalVal=0, totalPaid=0;
  const rows = data.map((row,i)=>{
    totalVal += parseFloat(row.itemValue)||0;
    totalPaid += parseFloat(row.dutyPaid)||0;
    return `<tr>
      <td><input data-i="${i}" data-f="date" value="${row.date||''}" placeholder="date"></td>
      <td><input data-i="${i}" data-f="ref" value="${esc(row.ref||'')}" placeholder="EC #"></td>
      <td><input class="num" type="number" step="0.01" data-i="${i}" data-f="itemValue" value="${row.itemValue||''}"></td>
      <td><input class="num" type="number" step="0.01" data-i="${i}" data-f="dutyPaid" value="${row.dutyPaid||''}"></td>
      <td><button class="delbtn" data-i="${i}" data-del="1">✕</button></td>
    </tr>`;
  }).join('');
  container.innerHTML = `
    <h2>Duties</h2>
    <div class="pagesub">Customs duty/VAT already paid on imported items, per entry number (USD).</div>
    <table>
      <thead><tr><th>Date</th><th>Reference (EC#)</th><th style="text-align:right">Item Value</th><th style="text-align:right">Duty/VAT Paid</th><th></th></tr></thead>
      <tbody>${rows || emptyRow(5)}</tbody>
      <tfoot><tr><td colspan="2">TOTAL</td><td class="num" id="ft-val">${fmt(totalVal)}</td><td class="num" id="ft-paid">${fmt(totalPaid)}</td><td></td></tr></tfoot>
    </table>
    <button class="addrow" data-add="1">+ Add line</button>
  `;
  wireDutiesTable(container, data);
}

function recalcDutiesTable(container){
  const data = q().duties;
  let totalVal=0, totalPaid=0;
  data.forEach(row=>{
    totalVal += parseFloat(row.itemValue)||0;
    totalPaid += parseFloat(row.dutyPaid)||0;
  });
  const v = container.querySelector('#ft-val'); if(v) v.textContent = fmt(totalVal);
  const p = container.querySelector('#ft-paid'); if(p) p.textContent = fmt(totalPaid);
}

function wireDutiesTable(container, data){
  container.querySelectorAll('tbody input').forEach(el=>{
    el.addEventListener('input', ()=>{
      const i = +el.dataset.i, f = el.dataset.f;
      data[i][f] = el.value;
      save();
      if(f==='itemValue' || f==='dutyPaid') recalcDutiesTable(container);
    });
  });
  container.querySelectorAll('[data-del]').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      data.splice(+btn.dataset.i,1);
      save(); renderPage();
    });
  });
  const addBtn = container.querySelector('[data-add]');
  if(addBtn) addBtn.addEventListener('click', ()=>{
    data.push({date:'',ref:'',itemValue:'',dutyPaid:''});
    save(); renderPage();
  });
}

function emptyRow(cols){
  return `<tr><td colspan="${cols}" style="padding:14px;color:var(--muted);text-align:center">No entries yet — click "Add line" below.</td></tr>`;
}
function esc(s){ return String(s).replace(/"/g,'&quot;'); }
function label(key){
  return {utilities:'Utilities', localSpending:'Local Spending', supplies:'Supplies', repairs:'Repairs', travel:'Travel'}[key] || key;
}

/* ---------------- Revenue page ---------------- */
function renderRevenue(container){
  const s = q();
  const r = s.revenue;
  const fields = [
    ['totalPayouts','Total Payouts (from platforms)'],
    ['cleaning','Cleaning'],
    ['management','Management'],
    ['platformFee','Platform Fee'],
  ];
  const travelTotal = getTravelTotalUSD();
  const computeBox4 = ()=>{
    const paypalFee = (parseFloat(r.totalPayouts)||0) * (s.paypalFeeRate||0);
    return (parseFloat(r.totalPayouts)||0) - fields.slice(1).reduce((sum,[k])=>sum+(parseFloat(r[k])||0),0) - paypalFee - travelTotal;
  };
  const paypalFee = (parseFloat(r.totalPayouts)||0) * (s.paypalFeeRate||0);
  container.innerHTML = `
    <h2>Sales Revenue</h2>
    <div class="pagesub">These feed Box 4 on the VAT Return Summary. Net revenue = Total Payouts minus the fees/commissions below.</div>
    <div class="card">
      ${fields.map(([k,l])=>`
        <div class="field">
          <label>${l}</label>
          <input type="number" step="0.01" data-f="${k}" value="${r[k]||''}">
        </div>`).join('')}
      <div class="field">
        <label>Travel Expenses (USD, from Travel tab)</label>
        <div id="travelDisplay" style="font-size:14px;color:var(--muted);padding:8px 10px;background:var(--blue-light);border-radius:5px;">${fmt(travelTotal)}</div>
      </div>
      <div class="field">
        <label>PayPal Fee (${((s.paypalFeeRate||0)*100).toFixed(1)}% of Total Payouts, auto-calculated)</label>
        <div id="paypalFeeDisplay" style="font-size:14px;color:var(--muted);padding:8px 10px;background:var(--blue-light);border-radius:5px;">${fmt(paypalFee)}</div>
      </div>
      <div class="field">
        <label>Total for Box 4 (net)</label>
        <div id="box4Display" style="font-size:18px;font-weight:700;color:var(--navy)">${fmt(computeBox4())}</div>
      </div>
    </div>
  `;
  container.querySelectorAll('input').forEach(el=>{
    el.addEventListener('input', ()=>{
      r[el.dataset.f] = el.value;
      save();
      const pf = (parseFloat(r.totalPayouts)||0) * (s.paypalFeeRate||0);
      const pfDisp = container.querySelector('#paypalFeeDisplay');
      if(pfDisp) pfDisp.textContent = fmt(pf);
      const disp = container.querySelector('#box4Display');
      if(disp) disp.textContent = fmt(computeBox4());
    });
  });
}

/* ---------------- Settings page ---------------- */
function renderSettings(container){
  const s = q();
  const companyCardHtml = (FS_SUPPORTED && REGISTRY && ACTIVE_COMPANY) ? `
    <div class="card" style="margin-bottom:20px">
      <h3 style="margin-top:0;color:var(--navy);font-size:15px">Company Info</h3>
      <div class="field">
        <label>Company Name</label>
        <input type="text" id="companyNameInput" value="${esc(ACTIVE_COMPANY.name)}">
        <div class="hint">Shown in the Company dropdown in the sidebar.</div>
      </div>
      <div class="field">
        <label>Data File</label>
        <input type="text" value="${esc(ACTIVE_COMPANY.file)}" disabled style="background:#f4f6fa;color:var(--muted)">
        <div class="hint">Stored in your chosen data folder alongside your other companies' files.</div>
      </div>
    </div>
  ` : '';
  container.innerHTML = `
    <h2>Settings</h2>
    <div class="pagesub">Applies to the currently selected quarter (${DATA.currentQuarter}).</div>
    ${companyCardHtml}
    <div class="card">
      <div class="field">
        <label>VAT Rate</label>
        <input type="number" step="0.001" id="vatRate" value="${(s.vatRate*100).toFixed(2)}">
        <div class="hint">Enter as a percentage, e.g. 10 for 10%</div>
      </div>
      <div class="field">
        <label>CDN → USD Exchange Rate</label>
        <input type="number" step="0.0001" id="exRate" value="${s.exchangeRate}">
        <div class="hint">CDN per 1 USD — update from your bank/CRA rate each quarter</div>
      </div>
      <div class="field">
        <label>PayPal Fee Rate</label>
        <input type="number" step="0.01" id="paypalFeeRate" value="${((s.paypalFeeRate||0)*100).toFixed(2)}">
        <div class="hint">Enter as a percentage, e.g. 3 for 3%. Applied to Total Payouts on the Sales Revenue page.</div>
      </div>
      <div class="field">
        <label>Default Currency for New Entries</label>
        <select id="defaultCurrency" style="width:100%;padding:8px 10px;border:1px solid var(--border);border-radius:5px;font-size:14px;">
          <option value="USD" ${(s.defaultCurrency||'USD')==='USD'?'selected':''}>USD</option>
          <option value="CDN" ${s.defaultCurrency==='CDN'?'selected':''}>CDN</option>
        </select>
        <div class="hint">Applies to new lines added on Supplies, Repairs and Travel. Existing entries are unaffected.</div>
      </div>
    </div>
    <div class="toolbar" style="margin-top:20px">
      <button class="toolbtn" id="exportBtn">Export backup (JSON)</button>
      <button class="toolbtn" id="importBtn">Import backup (JSON)</button>
      <button class="toolbtn" id="printBtn">Print VAT Summary</button>
    </div>
  `;
  const companyNameInput = document.getElementById('companyNameInput');
  if(companyNameInput){
    let renameTimer = null;
    companyNameInput.addEventListener('input', e=>{
      clearTimeout(renameTimer);
      const newName = e.target.value;
      renameTimer = setTimeout(()=> renameActiveCompany(newName), 400);
    });
  }
  document.getElementById('vatRate').addEventListener('input', e=>{
    s.vatRate = (parseFloat(e.target.value)||0)/100; save();
  });
  document.getElementById('exRate').addEventListener('input', e=>{
    s.exchangeRate = parseFloat(e.target.value)||1; save();
  });
  document.getElementById('paypalFeeRate').addEventListener('input', e=>{
    s.paypalFeeRate = (parseFloat(e.target.value)||0)/100; save();
  });
  document.getElementById('defaultCurrency').addEventListener('change', e=>{
    s.defaultCurrency = e.target.value; save();
  });
  document.getElementById('exportBtn').addEventListener('click', exportJSON);
  document.getElementById('importBtn').addEventListener('click', ()=>document.getElementById('fileInput').click());
  document.getElementById('printBtn').addEventListener('click', ()=>{ currentPage='summary'; renderSidebar(); renderPage(); setTimeout(()=>window.print(),150); });
}

/* ---------------- Summary page ---------------- */
function computeSummary(){
  const s = q();
  const rate = s.vatRate, er = s.exchangeRate;

  const utilTotal = s.utilities.reduce((a,r)=>a+(parseFloat(r.amount)||0),0);
  const utilVat = s.utilities.reduce((a,r)=>a+vatOf(r.amount,r.vat,rate),0);
  const utilBefore = utilTotal - utilVat;

  const localTotal = s.localSpending.reduce((a,r)=>a+(parseFloat(r.amount)||0),0);
  const localVat = s.localSpending.reduce((a,r)=>a+vatOf(r.amount,r.vat,rate),0);
  const localBefore = localTotal - localVat;

  const suppliesTotal = s.supplies.reduce((a,r)=>a+usd(r.amount,r.currency,er),0);
  const repairsTotal = s.repairs.reduce((a,r)=>a+usd(r.amount,r.currency,er),0);
  const box13 = suppliesTotal + repairsTotal;
  const box14 = box13*rate;
  const box17 = repairsTotal;

  const dutiesVal = s.duties.reduce((a,r)=>a+(parseFloat(r.itemValue)||0),0);
  const dutiesPaid = s.duties.reduce((a,r)=>a+(parseFloat(r.dutyPaid)||0),0);

  const domesticVat = utilVat + dutiesPaid;
  const box19 = localBefore + utilBefore;
  const box18 = box19 + dutiesVal;

  const travelTotal = getTravelTotalUSD();

  const rev = s.revenue;
  const paypalFee = (parseFloat(rev.totalPayouts)||0) * (s.paypalFeeRate||0);
  const box4 = (parseFloat(rev.totalPayouts)||0) - ['cleaning','management','platformFee'].reduce((a,k)=>a+(parseFloat(rev[k])||0),0) - paypalFee - travelTotal;

  return {utilTotal,utilVat,utilBefore,localTotal,localVat,localBefore,suppliesTotal,repairsTotal,
    box13,box14,box17,dutiesVal,dutiesPaid,domesticVat,box19,box18,travelTotal,box4};
}

function renderSummary(container){
  const c = computeSummary();
  container.innerHTML = `
    <h2>VAT Return Summary</h2>
    <div class="pagesub">Quarter: ${DATA.currentQuarter} — everything below recalculates live from your entries.</div>
    <div class="sumgrid">
      <div class="sumcard boxcard">
        <h3>Revenue <span class="boxtag">Box 4</span></h3>
        <div class="sumrow total"><span>Net Rental Revenue</span><span>${fmt(c.box4)}</span></div>
      </div>

      <div class="sumcard">
        <h3>Imported Goods</h3>
        <div class="sumrow"><span>Supplies (USD)</span><span>${fmt(c.suppliesTotal)}</span></div>
        <div class="sumrow"><span>Repairs (USD)</span><span>${fmt(c.repairsTotal)}</span></div>
        <div class="sumrow total"><span>Total Imported Goods <span class="boxtag">Box 13</span></span><span>${fmt(c.box13)}</span></div>
      </div>
      <div class="sumcard">
        <h3>Import VAT / Capital</h3>
        <div class="sumrow total"><span>VAT on Imported Goods <span class="boxtag">Box 14</span></span><span>${fmt(c.box14)}</span></div>
        <div class="sumrow total"><span>Repairs (Capital) <span class="boxtag">Box 17</span></span><span>${fmt(c.box17)}</span></div>
      </div>

      <div class="sumcard">
        <h3>Local Expenses</h3>
        <div class="sumrow"><span>Utilities — Before VAT</span><span>${fmt(c.utilBefore)}</span></div>
        <div class="sumrow"><span>Utilities — VAT</span><span>${fmt(c.utilVat)}</span></div>
        <div class="sumrow"><span>Local Spending — Before VAT</span><span>${fmt(c.localBefore)}</span></div>
        <div class="sumrow"><span>Local Spending — VAT</span><span>${fmt(c.localVat)}</span></div>
        <div class="sumrow"><span>Duties — Item Value</span><span>${fmt(c.dutiesVal)}</span></div>
        <div class="sumrow"><span>Duties — VAT/Duty Paid</span><span>${fmt(c.dutiesPaid)}</span></div>
      </div>
      <div class="sumcard">
        <h3>Domestic VAT</h3>
        <div class="sumrow total"><span>Domestic VAT (Utilities + Duties)</span><span>${fmt(c.domesticVat)}</span></div>
      </div>

      <div class="sumcard boxcard">
        <h3>Local Purchases <span class="boxtag">Box 19</span> / <span class="boxtag">Box 18</span></h3>
        <div class="sumrow"><span>Local Expenses (Box 19)</span><span>${fmt(c.box19)}</span></div>
        <div class="sumrow total"><span>Box 18 Subtotal</span><span>${fmt(c.box18)}</span></div>
      </div>

      <div class="sumcard">
        <h3>Informational — Travel</h3>
        <div class="sumrow"><span>Travel Total (USD, not mapped to a box)</span><span>${fmt(c.travelTotal)}</span></div>
      </div>
    </div>
    <div class="pagesub" style="margin-top:18px">Box mappings follow your prior filing convention — confirm box numbers against the current Bahamas VAT return form each quarter, as they can change.</div>
  `;
}

/* ---------------- Router ---------------- */
function renderPage(){
  const main = document.getElementById('main');
  main.innerHTML = `<div class="page active" id="pageBody"></div>`;
  const body = document.getElementById('pageBody');
  switch(currentPage){
    case 'summary': renderSummary(body); break;
    case 'revenue': renderRevenue(body); break;
    case 'utilities': renderSimpleVatTable(body, {key:'utilities'}); break;
    case 'localSpending': renderSimpleVatTable(body, {key:'localSpending'}); break;
    case 'supplies': renderImportTable(body, {key:'supplies'}); break;
    case 'repairs': renderImportTable(body, {key:'repairs'}); break;
    case 'travel': renderImportTable(body, {key:'travel'}); break;
    case 'duties': renderDuties(body); break;
    case 'settings': renderSettings(body); break;
  }
}

/* ---------------- Import / Export ---------------- */
function exportJSON(){
  const blob = new Blob([JSON.stringify(DATA,null,2)], {type:'application/json'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = `bahamas_vat_backup_${DATA.currentQuarter}.json`;
  a.click();
  URL.revokeObjectURL(url);
  toast('Backup exported');
}
document.getElementById('fileInput').addEventListener('change', (e)=>{
  const file = e.target.files[0];
  if(!file) return;
  const reader = new FileReader();
  reader.onload = ()=>{
    try{
      const parsed = JSON.parse(reader.result);
      if(!parsed.quarters) throw new Error('Invalid file');
      DATA = parsed;
      save(); renderSidebar(); renderPage();
      toast('Backup imported');
    }catch(err){ alert('Could not read that file: '+err.message); }
  };
  reader.readAsText(file);
  e.target.value = '';
});

/* ---------------- Init ---------------- */
function promptForCompanyName(){
  return new Promise((resolve)=>{
    document.getElementById('main').innerHTML = `
      <div style="padding:40px;max-width:480px">
        <h2>Name This Company</h2>
        <p style="color:var(--muted);font-size:14px;line-height:1.5">
          This folder doesn't have any VAT Tracker data yet. Give this company a name to get started
          — you can rename it anytime in Settings, and add more companies later.
        </p>
        <div class="field">
          <label>Company Name</label>
          <input type="text" id="firstCompanyNameInput" placeholder="e.g. Erin & Kathy">
        </div>
        <button class="addrow" id="firstCompanyNameBtn">Continue</button>
      </div>`;
    const input = document.getElementById('firstCompanyNameInput');
    input.focus();
    const submit = ()=>{
      const name = input.value.trim() || 'Company 1';
      resolve(name);
    };
    document.getElementById('firstCompanyNameBtn').onclick = submit;
    input.addEventListener('keydown', e=>{ if(e.key==='Enter') submit(); });
  });
}

function showChooseFolderScreen(message){
  document.getElementById('main').innerHTML = `
    <div style="padding:40px;max-width:520px">
      <h2>Choose a Data Folder</h2>
      <p style="color:var(--muted);font-size:14px;line-height:1.5">
        ${message || 'Select the folder where your VAT Tracker data lives - for example your existing OneDrive BahamasVatTracker folder. This is a one-time step; after this, all saves happen automatically in the background.'}
      </p>
      <button class="addrow" id="chooseFolderBtn">Choose Folder</button>
    </div>`;
  document.getElementById('chooseFolderBtn').onclick = async ()=>{
    try{
      await getRootDir(true);
      location.reload();
    }catch(err){ console.error('Folder selection failed', err); }
  };
}

(async function init(){
  if(!FS_SUPPORTED){
    console.warn('File System Access API not supported in this browser (use Chrome or Edge). Falling back to browser-only storage.');
  }
  try{
    DATA = await initStorage();
  }catch(e){
    console.error('Storage init failed, prompting for folder', e);
    showChooseFolderScreen();
    return;
  }
  renderSidebar();
  renderPage();
  setSaveStatus('saved');
})();